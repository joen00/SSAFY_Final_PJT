-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafy_home
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `no` int NOT NULL AUTO_INCREMENT,
  `bno` int NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `ccontent` text NOT NULL,
  `write_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`no`),
  KEY `bno` (`bno`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`bno`) REFERENCES `qna_board` (`bno`),
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `member` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` (`no`, `bno`, `user_id`, `ccontent`, `write_date`) VALUES (1,184,'ssafy','comment Test','2022-11-22 07:21:20'),(2,184,'ssafy','ㅋㅋㅋㅋ','2022-11-22 07:43:14'),(3,184,'ssafy','ㅋㅋㅋㅋㅋㅋㅋㅋ','2022-11-22 07:45:42'),(4,184,'ssafy','ㅋㅋㅋㅋ','2022-11-22 07:46:06'),(5,184,'ssafy','ㅋㅋㅋㅋ','2022-11-22 07:46:11'),(6,184,'ssafy','ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ','2022-11-22 07:46:21'),(7,184,'ssafy','ㅋㅋㅋㅋ','2022-11-22 14:33:34'),(8,184,'ssafy','이게 들어갈까?','2022-11-22 14:33:57'),(9,184,'ssafy','드가자~','2022-11-22 14:36:14'),(10,184,'ssafy','zzzz','2022-11-22 15:35:43'),(11,183,'ssafy','서윤아 오늘 밥 뭐야?','2022-11-22 15:42:38'),(12,184,'ssafy','테스트','2022-11-22 23:53:38'),(13,184,'ssafy','테스트2','2022-11-22 23:55:09'),(14,184,'ssafy','ㅋㅋㅋ','2022-11-22 23:58:06'),(15,184,'ssafy','zzzzz','2022-11-22 23:58:49'),(16,184,'ssafy','asdf','2022-11-23 00:12:48'),(17,184,'ssafy','asdfasdfasdf','2022-11-23 00:13:09'),(18,183,'ssafy','오늘 밥 별로...','2022-11-23 03:23:31'),(19,183,'ssafy','ㅁㄴㅇㄹ','2022-11-23 03:23:43'),(20,184,'test','테스트!!','2022-11-23 03:48:21'),(21,184,'test','ㅋㅋ','2022-11-23 03:49:26'),(22,184,'test','ㅁㄴㅇ','2022-11-23 03:49:32'),(23,187,'joen00','asdf','2022-11-23 11:18:56'),(24,187,'joen00','안녕하세요','2022-11-23 13:45:41'),(25,161,'test','zz','2022-11-23 14:23:38'),(26,184,'test','zzz','2022-11-23 15:29:18'),(27,188,'test','emdfhr','2022-11-24 14:00:16'),(28,188,'test','등록!!','2022-11-24 14:00:20'),(29,190,'strong8749','거기 빽다방 맛있어요!','2022-11-24 14:03:10'),(30,204,'strong8749','ㅋㅋㅋ','2022-11-24 14:18:07'),(31,205,'strong8749','ㅋㅋㅋ','2022-11-24 14:18:13'),(32,191,'strong8749','ㅋㅋㅋ','2022-11-24 14:18:22'),(33,191,'strong8749','ㅋㅋㅋㅋㅋ','2022-11-24 14:18:27'),(34,205,'strong8749','ㅋㅋㅋㅋㅋㅋㅋㅋ','2022-11-24 14:18:37'),(35,205,'akim','저도 궁금합니다!!','2022-11-24 14:19:58'),(36,205,'strong8749','야밐','2022-11-24 14:32:06');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-25  2:26:23
